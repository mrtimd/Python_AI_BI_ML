from openai import OpenAI

# Get connection info
endpoint = input("Project Endpoint: ").strip()
api_key = input("API Key: ").strip()
deployment = input("Model Deployment Name: ").strip()

# Build client
client = OpenAI(
    api_key=api_key,
    base_url=f"{endpoint}/openai/v1/"
)

print("\nConnected.")
print("Type 'exit' to quit.\n")

# Chat loop
while True:
    prompt = input("You: ")

    if prompt.lower() in ["exit", "quit"]:
        break

    response = client.responses.create(
        model=deployment,
        input=prompt
    )

    print("\nAI:")
    print(response.output_text)
    print()