from openai import OpenAI

endpoint = input("Project Endpoint: ").strip().rstrip("/")
api_key = input("API Key: ").strip()
deployment = input("Model Deployment Name: ").strip()

try:
    client = OpenAI(
        api_key=api_key,
        base_url=f"{endpoint}/openai/v1/"
    )

    print("\nConnection ready.")
    print("Type 'exit' to quit.\n")

    while True:
        prompt = input("You: ")

        if prompt.lower() in ["exit", "quit"]:
            print("Goodbye.")
            break

        try:
            response = client.responses.create(
                model=deployment,
                input=prompt
            )

            print("\nAI:")
            print(response.output_text)
            print()

        except Exception as ex:
            print(f"\nRequest failed: {ex}\n")

except Exception as ex:
    print(f"\nConnection failed: {ex}")