# Mini regression demo in Python: predict house price from features
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt
#from caas_jupyter_tools import display_dataframe_to_user
 
# 1) Create a small synthetic dataset
rng = np.random.default_rng(42)
n = 120
 
size_m2 = rng.normal(120, 35, n).clip(40, 250)
rooms = rng.integers(1, 6, n)
age_years = rng.normal(25, 10, n).clip(1, 60)
dist_center_km = rng.normal(8, 3, n).clip(0.5, 20)
 
# True underlying relationship (unknown to the model)
# base + 300 * size + 20_000 * rooms - 800 * age - 2_000 * dist + noise
noise = rng.normal(0, 20_000, n)
price = 40_000 + 300 * size_m2 + 20_000 * rooms - 800 * age_years - 2_000 * dist_center_km + noise
 
df = pd.DataFrame({
    "size_m2": size_m2.round(1),
    "rooms": rooms,
    "age_years": age_years.round(1),
    "dist_center_km": dist_center_km.round(1),
    "price": price.round(0).astype(int)
})
 
# Save for the user
# csv_path = "/mnt/data/house_prices_demo.csv"
# df.to_csv(csv_path, index=False)
 
# Show the data to the user
print( df.head(15))
 
# 2) Train/test split
X = df[["size_m2", "rooms", "age_years", "dist_center_km"]]
y = df["price"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
 
# 3) Train a linear regression model
model = LinearRegression()
model.fit(X_train, y_train)
 
# 4) Evaluate
pred = model.predict(X_test)
r2 = r2_score(y_test, pred)
mae = mean_absolute_error(y_test, pred)
rmse = np.sqrt(mean_squared_error(y_test, pred))
 
coef_table = pd.DataFrame({
    "feature": X.columns,
    "coefficient": model.coef_
}).sort_values("coefficient", ascending=False).reset_index(drop=True)
 
# 5) Plot size vs price with a fitted line (univariate view for intuition)
plt.figure()
plt.scatter(X_test["size_m2"], y_test)
# Sort by size to draw a clean line
order = np.argsort(X_test["size_m2"].values)
size_sorted = X_test["size_m2"].values[order]
# Build a line using average values for other features (partial effect visualization)
rooms_mean = X_test["rooms"].mean()
age_mean = X_test["age_years"].mean()
dist_mean = X_test["dist_center_km"].mean()
line_pred = (model.intercept_
             + model.coef_[0] * size_sorted
             + model.coef_[1] * rooms_mean
             + model.coef_[2] * age_mean
             + model.coef_[3] * dist_mean)
plt.plot(size_sorted, line_pred)
plt.title("Price vs Size (test set) with fitted line")
plt.xlabel("size_m2")
plt.ylabel("price")
plt.show()
 
# 6) Prepare a quick textual summary for the user
summary = {
    "R2_on_test": r2,
    "MAE_on_test": mae,
    "RMSE_on_test": rmse,
    "Intercept": model.intercept_,
    "Example_prediction_for": {
        "size_m2": 140,
        "rooms": 4,
        "age_years": 20,
        "dist_center_km": 6
    },
    "Predicted_price_example": float(model.predict(pd.DataFrame([{
        "size_m2": 140, "rooms": 4, "age_years": 20, "dist_center_km": 6
    }]))[0])
}
 
coef_table, summary#, csv_path
 