#GET Data User Input

x = input("message to user: ")
y = input("about what to do: ")
#baton or message passed in a relay race
#argument passed from input variable x to int parameter x
#Feed variable sum
sum = int(x) + int(y)

print("The sum is: ", sum)

#Get sum and write to the file?

#GET Data  from a file
#f = open("inside_Folder/demofile3.txt", "a")
#f.write("Now the file has more content!")
#f.close()

#open and read the file after the appending:
#f = open("demofile2.txt", "r")
#print(f.read())

#f = open("../source/demofile2.txt", "a")
#f.write("Now the file has more content!")
#f.close()
